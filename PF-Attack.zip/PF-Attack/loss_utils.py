from __future__ import absolute_import, division, print_function

import argparse
import math
import os
import sys
import time
import copy
import numpy as np
from pytorch3d.ops import knn_points, knn_gather
import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
from torch.autograd.gradcheck import zero_gradients
import scipy.io as io

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = BASE_DIR + '/../'
sys.path.append(BASE_DIR)
sys.path.append(os.path.join(ROOT_DIR, 'Model'))
from utility import _normalize


def chamfer_loss(adv_pc, ori_pc):
    adv_KNN = knn_points(adv_pc.permute(0,2,1), ori_pc.permute(0,2,1), K=1)
    ori_KNN = knn_points(ori_pc.permute(0,2,1), adv_pc.permute(0,2,1), K=1)
    dis_loss = adv_KNN.dists.contiguous().squeeze(-1).mean(-1) + ori_KNN.dists.contiguous().squeeze(-1).mean(-1)
    return dis_loss

def sample(delta, pp):
    b, s, n = delta.size()
    only_add_one_mask = torch.from_numpy(np.random.choice([0, 1], size=(b,s,n), p=[1 - pp, pp])).cuda()


    leave_one_mask = 1 - only_add_one_mask

    only_add_one_perturbation = delta * only_add_one_mask
    leave_one_out_perturbation = delta * leave_one_mask

    return only_add_one_perturbation, leave_one_out_perturbation

def get_features(
    model,
    x,
    perturbation,
    leave_one_out_perturbation,
    only_add_one_perturbation,
):

    outputs = model(x + perturbation)
    leave_one_outputs = model(x + leave_one_out_perturbation)
    only_add_one_outputs = model(x + only_add_one_perturbation)

    return (outputs, leave_one_outputs, only_add_one_outputs)

class PFLoss(nn.Module):

    def __init__(self, target=None, label=None):
        super(PFLoss, self).__init__()
        assert (target is not None) and (label is not None)
        self.target = target
        self.label = label.item()

    def logits_PF(self, outputs, leave_one_outputs,
                           only_add_one_outputs):

        complete_score = ((outputs[:, self.target] - outputs[:, self.label])**2)
        # print(complete_score)

        leave_one_out_score = ((leave_one_outputs[:, self.target] - leave_one_outputs[:, self.label])**2)
        only_add_one_score = ((only_add_one_outputs[:, self.target] -only_add_one_outputs[:, self.label])**2)

        average_pairwise = (complete_score + leave_one_out_score + only_add_one_score)

        return average_pairwise

    def forward(self, outputs, leave_one_outputs, only_add_one_outputs):
        return self.logits_PF(outputs, leave_one_outputs,
                                       only_add_one_outputs)