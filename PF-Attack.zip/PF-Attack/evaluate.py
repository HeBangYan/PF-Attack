from __future__ import absolute_import, division, print_function

import argparse
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable

from utility import farthest_points_sample

def main():

    # data 
    test_dataset = ModelNet40(cfg.datadir)
    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=1, shuffle=False, drop_last=False,
                                              num_workers=cfg.num_workers, pin_memory=True)
    test_size = test_dataset.__len__()

    # model
    model_path = os.path.join('Pretrained', cfg.arch, str(cfg.npoint), 'model_best.pth.tar')
    if cfg.arch == 'PointNet':
        from Model.PointNet import PointNet
        net = PointNet(cfg.classes, npoint=cfg.npoint).cuda()
    elif cfg.arch == 'PointNetPP_ssg':
        from Model.PointNetPP_ssg import PointNet2ClassificationSSG
        net = PointNet2ClassificationSSG(use_xyz=True, use_normal=False).cuda()
    elif cfg.arch == 'PointNetPP_msg':
        from Model.PointNetPP_msg import PointNet2ClassificationMSG
        net = PointNet2ClassificationMSG(use_xyz=True, use_normal=False).cuda()
    elif cfg.arch == 'DGCNN':
        from Model.DGCNN import DGCNN_cls
        net = DGCNN_cls(k=20, emb_dims=cfg.npoint, dropout=0.5).cuda()
    else:
        assert False, 'Not support such arch.'

    checkpoint = torch.load(model_path)
    net.load_state_dict(checkpoint['state_dict'])
    net.eval()
    print('\nSuccessfully load pretrained-model from {}\n'.format(model_path))

    cnt = 0
    num_pred_success = 0

    for i, (adv_pc, gt_label, attack_label) in enumerate(test_loader):
        b = adv_pc.size(0)
        assert b == 1
        cnt += 1

        if adv_pc.size(2) > cfg.npoint:
            # adv_pc = adv_pc[:,:,:cfg.npoint]
            adv_pc = farthest_points_sample(adv_pc.cuda(), cfg.npoint)

        with torch.no_grad():
            attack_output = net(adv_pc.cuda())

        pred_success = (torch.max(attack_output, 1)[1].data.cpu() == gt_label.view(-1)).sum() # [b, num_class]
        num_pred_success += pred_success

        if (i + 1) % cfg.print_freq == 0:
            print('[{0}/{1}]  attack success: {2:.2f}'.format(
                i + 1, len(test_loader), (1 - num_pred_success.item() / float(cnt)) * 100))

    final_acc = num_pred_success.item() / float(test_loader.dataset.__len__()) * 100
    print('\nfinal attack success: {0:.2f}'.format(100 - final_acc))

    print('\n Finished!')


if __name__ == '__main__':
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    ROOT_DIR = BASE_DIR
    sys.path.append(BASE_DIR)
    sys.path.append(os.path.join(ROOT_DIR, 'Model'))
    sys.path.append(os.path.join(ROOT_DIR, 'Lib'))
    sys.path.append(os.path.join(ROOT_DIR, 'Provider'))
    from loss_utils import *
    from Provider.eva_modelnet10_instance250 import ModelNet40

    parser = argparse.ArgumentParser(description='Point Cloud Evaluate')
    # ------------Dataset-----------------------
    parser.add_argument('--datadir', default='./result/DGCNN18', type=str, metavar='DIR',
                        help='path to dataset')
    parser.add_argument('--npoint', default=1024, type=int, help='')
    parser.add_argument('-c', '--classes', default=40, type=int, metavar='N', help='num of classes (default: 40)')
    # ------------Model-----------------------
    parser.add_argument('--arch', default='PointNetPP_msg', type=str, metavar='ARCH', help='')
    # ------------OS-----------------------
    parser.add_argument('-j', '--num_workers', default=8, type=int, metavar='N',
                        help='number of data loading workers (default: 8)')
    parser.add_argument('--print_freq', default=50, type=int, help='')

    cfg = parser.parse_args()
    print(cfg)

    assert cfg.datadir[-1] != '/'

    main()
